import json
import boto3
import os
import traceback


s3_client = boto3.client("s3")
lambda_client = boto3.client("lambda")


# =========================================================
# CONFIGURATION
# =========================================================

BUCKET_NAME = "resumatch-resumes-new"

RESUME_REPORT_FUNCTION = os.environ.get(
    "RESUME_REPORT_FUNCTION",
    "resume_report"
)


# =========================================================
# CORS HEADERS
# =========================================================

def cors_headers():
    return {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "OPTIONS,POST",
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
    }


def response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": cors_headers(),
        "body": json.dumps(body)
    }


# =========================================================
# GET HTTP METHOD
# =========================================================

def get_http_method(event):

    # REST API Gateway
    if event.get("httpMethod"):
        return event.get("httpMethod")

    # HTTP API Gateway
    return (
        event.get("requestContext", {})
        .get("http", {})
        .get("method")
    )


# =========================================================
# GET REQUEST PATH
# =========================================================

def get_request_path(event):

    # REST API Gateway
    if event.get("resource"):
        return event.get("resource")

    if event.get("path"):
        return event.get("path")

    # HTTP API Gateway
    return (
        event.get("requestContext", {})
        .get("http", {})
        .get("path", "")
    )


# =========================================================
# MAIN LAMBDA
# =========================================================

def lambda_handler(event, context):

    print("========================================")
    print("EVENT RECEIVED")
    print(json.dumps(event))
    print("========================================")

    http_method = get_http_method(event)
    path = get_request_path(event)

    print("HTTP METHOD:", http_method)
    print("REQUEST PATH:", path)

    # =====================================================
    # CORS PREFLIGHT
    # =====================================================

    if http_method == "OPTIONS":
        return response(200, {})

    try:

        # =================================================
        # READ REQUEST BODY
        # =================================================

        raw_body = event.get("body")

        if not raw_body:
            return response(
                400,
                {
                    "error": "No request body received"
                }
            )

        if isinstance(raw_body, str):
            body = json.loads(raw_body)
        else:
            body = raw_body

        print("REQUEST BODY:")
        print(json.dumps(body))

        # =================================================
        # ROUTE 1
        # GENERATE PRESIGNED URL
        # =================================================

        if "generatepresignedurl" in path.lower():

            file_name = body.get("fileName")

            if not file_name:
                return response(
                    400,
                    {
                        "error": "Missing 'fileName'"
                    }
                )

            print("Generating presigned URL")
            print("Bucket:", BUCKET_NAME)
            print("File:", file_name)

            # For now, use filename as S3 key
            key = file_name

            upload_url = s3_client.generate_presigned_url(
                ClientMethod="put_object",
                Params={
                    "Bucket": BUCKET_NAME,
                    "Key": key
                },
                ExpiresIn=3600
            )

            return response(
                200,
                {
                    "uploadUrl": upload_url,
                    "key": key
                }
            )

        # =================================================
        # ROUTE 2
        # GENERATE PRESIGNED DOWNLOAD URL
        # =================================================

        elif "generatepresigneddownloadurl" in path.lower():

            key = body.get("key")

            if not key:
                return response(
                    400,
                    {
                        "error": "Missing 'key'"
                    }
                )

            print("Generating presigned download URL")
            print("Bucket:", BUCKET_NAME)
            print("Key:", key)

            download_url = s3_client.generate_presigned_url(
                ClientMethod="get_object",
                Params={
                    "Bucket": BUCKET_NAME,
                    "Key": key
                },
                ExpiresIn=3600
            )

            return response(
                200,
                {
                    "downloadUrl": download_url
                }
            )

        # =================================================
        # ROUTE 3
        # ANALYZE RESUME
        # =================================================

        elif "resume-upload" in path.lower():

            bucket = body.get("bucket")
            file_name = body.get("fileName")
            jd_text = body.get("jd_text", "")

            if not bucket:
                return response(
                    400,
                    {
                        "error": "Missing 'bucket'"
                    }
                )

            if not file_name:
                return response(
                    400,
                    {
                        "error": "Missing 'fileName'"
                    }
                )

            print("========================================")
            print("RESUME ANALYSIS REQUEST")
            print("Bucket:", bucket)
            print("File:", file_name)
            print("JD Length:", len(jd_text))
            print("========================================")

            # =============================================
            # PAYLOAD FOR resume_report LAMBDA
            # =============================================

            report_payload = {
                "httpMethod": "POST",
                "body": json.dumps(
                    {
                        "bucket": bucket,
                        "fileName": file_name,
                        "jd_text": jd_text
                    }
                )
            }

            print(
                f"Invoking Lambda: "
                f"{RESUME_REPORT_FUNCTION}"
            )

            # =============================================
            # INVOKE resume_report
            # =============================================

            invoke_response = lambda_client.invoke(
                FunctionName=RESUME_REPORT_FUNCTION,
                InvocationType="RequestResponse",
                Payload=json.dumps(
                    report_payload
                ).encode("utf-8")
            )

            # =============================================
            # READ RESPONSE
            # =============================================

            response_payload = (
                invoke_response["Payload"]
                .read()
                .decode("utf-8")
            )

            print("resume_report RESPONSE:")
            print(response_payload)

            if not response_payload:
                return response(
                    500,
                    {
                        "error": "Empty response from resume_report Lambda"
                    }
                )

            report_response = json.loads(
                response_payload
            )

            # =============================================
            # HANDLE LAMBDA FAILURE
            # =============================================

            if invoke_response.get("FunctionError"):

                print("❌ FULL resume_report ERROR:")
                print(json.dumps(report_response, indent=2))
            
                return response(
                    500,
                    {
                        "error": "resume_report Lambda failed",
                        "details": report_response
                    }
                )
            # =============================================
            # EXTRACT RESPONSE
            # =============================================

            status_code = report_response.get(
                "statusCode",
                500
            )

            report_body = report_response.get(
                "body",
                "{}"
            )

            if isinstance(report_body, str):

                try:
                    report_body = json.loads(
                        report_body
                    )

                except json.JSONDecodeError:

                    report_body = {
                        "result": report_body
                    }

            return response(
                status_code,
                report_body
            )

        # =================================================
        # UNKNOWN ROUTE
        # =================================================

        else:

            return response(
                404,
                {
                    "error": "Unknown API endpoint",
                    "path": path
                }
            )

    except json.JSONDecodeError as e:

        print("INVALID JSON:", str(e))

        return response(
            400,
            {
                "error": "Invalid JSON request body"
            }
        )

    except Exception as e:

        print("ERROR IN resume_analysis:")
        print(str(e))

        traceback.print_exc()

        return response(
            500,
            {
                "error": str(e)
            }
        )