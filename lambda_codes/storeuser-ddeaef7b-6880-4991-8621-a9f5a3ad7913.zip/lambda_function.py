import json
import boto3
from botocore.exceptions import ClientError


# ============================================================
# AWS CLIENTS
# ============================================================

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("resumatch_users")

cognito_client = boto3.client("cognito-idp")


USER_POOL_ID = "ap-south-1_a4CWKGPvR"
CLIENT_ID = "4it3r2nsl16upibofjo9rf10ba"


# ============================================================
# CORS
# ============================================================

def cors_headers():
    return {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "OPTIONS,GET,POST,PUT,DELETE",
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
    }


def response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": cors_headers(),
        "body": json.dumps(body),
    }


# ============================================================
# LAMBDA HANDLER
# ============================================================

def lambda_handler(event, context):

    print("EVENT RECEIVED:")
    print(json.dumps(event))

    method = event.get("httpMethod", "").upper()

    try:

        # ====================================================
        # OPTIONS - CORS PREFLIGHT
        # ====================================================

        if method == "OPTIONS":
            return response(200, {
                "message": "CORS OK"
            })


        # ====================================================
        # POST
        #
        # action = signup  -> Create user
        # action = login   -> Login user
        # ====================================================

        if method == "POST":

            body = event.get("body", {})

            if isinstance(body, str):
                body = json.loads(body)

            action = body.get("action", "signup").lower()

            # =================================================
            # LOGIN
            # =================================================

            if action == "login":

                email = body.get(
                    "email",
                    ""
                ).strip().lower()

                password = body.get(
                    "password",
                    ""
                )

                if not email:
                    return response(400, {
                        "error": "Email is required"
                    })

                if not password:
                    return response(400, {
                        "error": "Password is required"
                    })

                print(
                    f"🔐 Login attempt for: {email}"
                )

                try:

                    auth_response = (
                        cognito_client.initiate_auth(
                            ClientId=CLIENT_ID,
                            AuthFlow="USER_PASSWORD_AUTH",
                            AuthParameters={
                                "USERNAME": email,
                                "PASSWORD": password
                            }
                        )
                    )

                    print("✅ Cognito authentication successful")

                    authentication_result = (
                        auth_response.get(
                            "AuthenticationResult"
                        )
                    )

                    # -------------------------------------------------
                    # Cognito may return a challenge instead of tokens
                    # -------------------------------------------------

                    if not authentication_result:

                        challenge_name = (
                            auth_response.get(
                                "ChallengeName"
                            )
                        )

                        return response(200, {
                            "message": "Authentication challenge required",
                            "challenge": challenge_name,
                            "session": auth_response.get(
                                "Session"
                            )
                        })

                    # -------------------------------------------------
                    # Get user information from DynamoDB
                    # -------------------------------------------------

                    user_result = table.get_item(
                        Key={
                            "email": email
                        }
                    )

                    user = user_result.get(
                        "Item",
                        {}
                    )

                    # -------------------------------------------------
                    # Return authentication tokens
                    # -------------------------------------------------

                    return response(200, {
                        "message": "Login successful",

                        "email": email,

                        "name": user.get(
                            "name",
                            ""
                        ),

                        "contact": user.get(
                            "contact",
                            ""
                        ),

                        "accessToken": authentication_result.get(
                            "AccessToken"
                        ),

                        "idToken": authentication_result.get(
                            "IdToken"
                        ),

                        "refreshToken": authentication_result.get(
                            "RefreshToken"
                        ),

                        "expiresIn": authentication_result.get(
                            "ExpiresIn"
                        ),

                        "tokenType": authentication_result.get(
                            "TokenType"
                        )
                    })

                except cognito_client.exceptions.UserNotConfirmedException:

                    return response(403, {
                        "error": "User account is not confirmed. Please verify your email."
                    })

                except cognito_client.exceptions.NotAuthorizedException:

                    return response(401, {
                        "error": "Invalid email or password"
                    })

                except cognito_client.exceptions.UserNotFoundException:

                    return response(401, {
                        "error": "Invalid email or password"
                    })

                except cognito_client.exceptions.PasswordResetRequiredException:

                    return response(403, {
                        "error": "Password reset is required"
                    })

                except cognito_client.exceptions.InvalidParameterException as e:

                    print(
                        "Cognito login parameter error:",
                        e
                    )

                    return response(400, {
                        "error": str(
                            e.response["Error"].get(
                                "Message",
                                "Invalid login parameters"
                            )
                        )
                    })

                except ClientError as e:

                    print(
                        "Cognito login error:",
                        e
                    )

                    return response(401, {
                        "error": e.response["Error"].get(
                            "Message",
                            "Login failed"
                        )
                    })


            # =================================================
            # SIGNUP
            # =================================================

            name = body.get(
                "name",
                ""
            ).strip()

            email = body.get(
                "email",
                ""
            ).strip().lower()

            contact = body.get(
                "contact",
                ""
            ).strip()

            password = body.get(
                "password",
                ""
            )

            if not name:
                return response(400, {
                    "error": "Name is required"
                })

            if not email:
                return response(400, {
                    "error": "Email is required"
                })

            if not password:
                return response(400, {
                    "error": "Password is required"
                })

            # ------------------------------------------------
            # Validate / normalize phone number
            # ------------------------------------------------

            if contact and not contact.startswith("+"):
                contact = "+91" + contact

            # ------------------------------------------------
            # Check whether user already exists in DynamoDB
            # ------------------------------------------------

            existing_user = table.get_item(
                Key={
                    "email": email
                }
            )

            if "Item" in existing_user:

                return response(409, {
                    "error": "User already exists"
                })

            # ------------------------------------------------
            # Create user in Cognito
            # ------------------------------------------------

            try:

                cognito_response = (
                    cognito_client.sign_up(
                        ClientId=CLIENT_ID,
                        Username=email,
                        Password=password,
                        UserAttributes=[
                            {
                                "Name": "email",
                                "Value": email
                            },
                            {
                                "Name": "name",
                                "Value": name
                            },
                            {
                                "Name": "phone_number",
                                "Value": contact
                            }
                        ]
                    )
                )

            except cognito_client.exceptions.UsernameExistsException:

                return response(409, {
                    "error": "Email is already registered"
                })

            except cognito_client.exceptions.InvalidPasswordException:

                return response(400, {
                    "error": "Password does not satisfy Cognito requirements"
                })

            except ClientError as e:

                print(
                    "Cognito signup error:",
                    e
                )

                return response(400, {
                    "error": e.response["Error"].get(
                        "Message",
                        "Signup failed"
                    )
                })

            # ------------------------------------------------
            # Store user in DynamoDB
            # ------------------------------------------------

            table.put_item(
                Item={
                    "email": email,
                    "name": name,
                    "contact": contact,
                    "password": password
                }
            )

            return response(201, {
                "message": "User registered successfully",
                "email": email,
                "name": name,
                "userConfirmed": cognito_response.get(
                    "UserConfirmed",
                    False
                )
            })


        # ====================================================
        # GET - GET USER BY EMAIL
        # ====================================================

        if method == "GET":

            query_params = (
                event.get(
                    "queryStringParameters"
                ) or {}
            )

            email = query_params.get(
                "email",
                ""
            ).strip().lower()

            if not email:

                return response(400, {
                    "error": "Email is required"
                })

            result = table.get_item(
                Key={
                    "email": email
                }
            )

            item = result.get("Item")

            if not item:

                return response(404, {
                    "error": "User not found"
                })

            return response(200, {
                "name": item.get(
                    "name",
                    ""
                ),
                "email": item.get(
                    "email",
                    ""
                ),
                "contact": item.get(
                    "contact",
                    ""
                ),
                "password": item.get(
                    "password",
                    ""
                )
            })


        # ====================================================
        # PUT - UPDATE USER
        # ====================================================

        if method == "PUT":

            body = event.get(
                "body",
                {}
            )

            if isinstance(body, str):
                body = json.loads(body)

            email = body.get(
                "email",
                ""
            ).strip().lower()

            if not email:

                return response(400, {
                    "error": "Email is required"
                })

            name = body.get("name")
            contact = body.get("contact")
            password = body.get("password")
            new_email = body.get("new_email")

            # ------------------------------------------------
            # Check existing user
            # ------------------------------------------------

            existing_user = table.get_item(
                Key={
                    "email": email
                }
            )

            if "Item" not in existing_user:

                return response(404, {
                    "error": "User not found"
                })

            # ------------------------------------------------
            # Update Cognito attributes
            # ------------------------------------------------

            cognito_attributes = []

            if name:

                cognito_attributes.append({
                    "Name": "name",
                    "Value": name
                })

            if new_email:

                new_email = (
                    new_email
                    .strip()
                    .lower()
                )

                cognito_attributes.append({
                    "Name": "email",
                    "Value": new_email
                })

                cognito_attributes.append({
                    "Name": "email_verified",
                    "Value": "false"
                })

            if cognito_attributes:

                try:

                    cognito_client.admin_update_user_attributes(
                        UserPoolId=USER_POOL_ID,
                        Username=email,
                        UserAttributes=cognito_attributes
                    )

                except ClientError as e:

                    print(
                        "Cognito attribute update error:",
                        e
                    )

                    return response(400, {
                        "error": e.response["Error"].get(
                            "Message",
                            "Failed to update Cognito attributes"
                        )
                    })

            # ------------------------------------------------
            # Update password
            # ------------------------------------------------

            if password:

                try:

                    cognito_client.admin_set_user_password(
                        UserPoolId=USER_POOL_ID,
                        Username=email,
                        Password=password,
                        Permanent=True
                    )

                except ClientError as e:

                    print(
                        "Cognito password update error:",
                        e
                    )

                    return response(400, {
                        "error": e.response["Error"].get(
                            "Message",
                            "Failed to update password"
                        )
                    })

            # ------------------------------------------------
            # DynamoDB update
            # ------------------------------------------------

            update_parts = []
            expression_values = {}

            if name is not None:

                update_parts.append(
                    "#name = :name"
                )

                expression_values[
                    ":name"
                ] = name

            if contact is not None:

                update_parts.append(
                    "#contact = :contact"
                )

                expression_values[
                    ":contact"
                ] = contact

            # ------------------------------------------------
            # Email changed
            # ------------------------------------------------

            if new_email:

                new_item = {
                    "email": new_email,

                    "name": (
                        name
                        if name is not None
                        else existing_user["Item"].get(
                            "name",
                            ""
                        )
                    ),

                    "contact": (
                        contact
                        if contact is not None
                        else existing_user["Item"].get(
                            "contact",
                            ""
                        )
                    )
                }

                table.put_item(
                    Item=new_item
                )

                table.delete_item(
                    Key={
                        "email": email
                    }
                )

            else:

                if update_parts:

                    table.update_item(
                        Key={
                            "email": email
                        },

                        UpdateExpression=(
                            "SET " +
                            ", ".join(
                                update_parts
                            )
                        ),

                        ExpressionAttributeNames={
                            "#name": "name",
                            "#contact": "contact"
                        },

                        ExpressionAttributeValues=(
                            expression_values
                        )
                    )

            return response(200, {
                "message": "User updated successfully",
                "email": (
                    new_email or email
                ),
                "name": name,
                "contact": contact
            })


        # ====================================================
        # DELETE - DELETE USER
        # ====================================================

        if method == "DELETE":

            body = event.get(
                "body",
                {}
            )

            if isinstance(body, str):
                body = json.loads(body)

            email = body.get(
                "email",
                ""
            ).strip().lower()

            if not email:

                return response(400, {
                    "error": "Email is required"
                })

            # ------------------------------------------------
            # Delete Cognito user
            # ------------------------------------------------

            try:

                cognito_client.admin_delete_user(
                    UserPoolId=USER_POOL_ID,
                    Username=email
                )

            except cognito_client.exceptions.UserNotFoundException:

                print(
                    "Cognito user not found. "
                    "Continuing with DynamoDB deletion."
                )

            except ClientError as e:

                print(
                    "Cognito delete error:",
                    e
                )

                return response(400, {
                    "error": e.response["Error"].get(
                        "Message",
                        "Failed to delete Cognito user"
                    )
                })

            # ------------------------------------------------
            # Delete DynamoDB user
            # ------------------------------------------------

            table.delete_item(
                Key={
                    "email": email
                }
            )

            return response(200, {
                "message": "User deleted successfully",
                "email": email
            })


        # ====================================================
        # METHOD NOT ALLOWED
        # ====================================================

        return response(405, {
            "error": "Method not allowed"
        })


    except json.JSONDecodeError:

        return response(400, {
            "error": "Invalid JSON body"
        })


    except Exception as e:

        print("UNEXPECTED ERROR:")
        print(str(e))

        return response(500, {
            "error": str(e)
        })