import json
import boto3
import os
import traceback


s3 = boto3.client("s3")

BUCKET_NAME = os.environ.get(
    "RESUME_BUCKET",
    "resumatch-resumes-new"
)


def cors_headers():
    return {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "OPTIONS,GET,DELETE",
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
    }


def response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": cors_headers(),
        "body": json.dumps(body, default=str),
    }


def generate_presigned_url(key):
    """
    Generate a temporary URL to securely access
    a private S3 object.
    """

    return s3.generate_presigned_url(
        ClientMethod="get_object",
        Params={
            "Bucket": BUCKET_NAME,
            "Key": key
        },
        ExpiresIn=3600
    )


def lambda_handler(event, context):

    print("🔍 EVENT RECEIVED:")
    print(json.dumps(event))

    # --------------------------------------------------
    # GET HTTP METHOD
    # --------------------------------------------------

    http_method = event.get("httpMethod")

    # Support API Gateway HTTP API
    if not http_method:
        http_method = (
            event
            .get("requestContext", {})
            .get("http", {})
            .get("method")
        )

    print("🌐 HTTP METHOD:", http_method)

    # --------------------------------------------------
    # CORS OPTIONS
    # --------------------------------------------------

    if http_method == "OPTIONS":

        print("✅ Handling OPTIONS request")

        return response(200, {})

    # ==================================================
    # GET RESUMES
    # ==================================================

    if http_method == "GET":

        try:

            resumes = []

            paginator = s3.get_paginator(
                "list_objects_v2"
            )

            for page in paginator.paginate(
                Bucket=BUCKET_NAME
            ):

                for obj in page.get(
                    "Contents",
                    []
                ):

                    key = obj["Key"]

                    print("🔎 Checking S3 object:", key)

                    # Ignore folders
                    if key.endswith("/"):
                        continue

                    # Ignore analysis reports
                    if key.startswith(
                        "resumes-reports/"
                    ):
                        continue

                    file_name = key.split("/")[-1]

                    extension = (
                        file_name
                        .lower()
                        .split(".")[-1]
                    )

                    # Only resume files
                    if extension not in {
                        "pdf",
                        "doc",
                        "docx",
                        "jpg",
                        "jpeg",
                        "png",
                    }:
                        continue

                    # --------------------------------------
                    # GENERATE RESUME PRESIGNED URL
                    # --------------------------------------

                    try:

                        resume_url = generate_presigned_url(
                            key
                        )

                        print(
                            "🔐 Resume URL generated:",
                            file_name
                        )

                    except Exception as url_error:

                        print(
                            "⚠️ Could not generate resume URL:",
                            str(url_error)
                        )

                        resume_url = None


                    # --------------------------------------
                    # REPORT KEY
                    # --------------------------------------

                    report_key = (
                        f"resumes-reports/"
                        f"{key}.json"
                    )

                    report_url = None


                    # --------------------------------------
                    # CHECK IF REPORT EXISTS
                    # --------------------------------------

                    try:

                        s3.head_object(
                            Bucket=BUCKET_NAME,
                            Key=report_key
                        )

                        report_url = (
                            generate_presigned_url(
                                report_key
                            )
                        )

                        print(
                            "🔐 Report URL generated:",
                            report_key
                        )

                    except Exception as report_error:

                        print(
                            "⚠️ Report not found:",
                            report_key
                        )


                    # --------------------------------------
                    # ADD RESUME
                    # --------------------------------------

                    resumes.append(
                        {
                            "fileName": file_name,

                            "key": key,

                            "bucket": BUCKET_NAME,

                            "size": obj.get(
                                "Size",
                                0
                            ),

                            "lastModified": (
                                obj["LastModified"]
                                .isoformat()
                                if obj.get(
                                    "LastModified"
                                )
                                else None
                            ),

                            # IMPORTANT
                            "resumeUrl": resume_url,

                            # IMPORTANT
                            "reportUrl": report_url,
                        }
                    )


            print(
                f"📄 Found {len(resumes)} resumes"
            )


            return response(
                200,
                {
                    "resumes": resumes
                }
            )


        except Exception as e:

            print(
                "❌ ERROR fetching resumes:",
                str(e)
            )

            traceback.print_exc()

            return response(
                500,
                {
                    "error": str(e)
                }
            )

    # ==================================================
    # DELETE RESUME
    # ==================================================

    if http_method == "DELETE":

        try:

            body = event.get("body")

            print(
                "📦 DELETE BODY:",
                body
            )


            if isinstance(body, str):

                body = json.loads(
                    body
                )


            if not body:

                return response(
                    400,
                    {
                        "error":
                        "Request body is required"
                    }
                )


            # IMPORTANT:
            # Receive S3 KEY, not only filename
            key = body.get(
                "key"
            )


            # Backward compatibility
            if not key:

                key = body.get(
                    "filename"
                )


            if not key:

                return response(
                    400,
                    {
                        "error":
                        "Resume key is required"
                    }
                )


            print(
                "🗑️ Deleting resume:",
                key
            )


            # ------------------------------------------
            # DELETE RESUME
            # ------------------------------------------

            s3.delete_object(
                Bucket=BUCKET_NAME,
                Key=key
            )


            # ------------------------------------------
            # DELETE REPORT
            # ------------------------------------------

            report_key = (
                f"resumes-reports/"
                f"{key}.json"
            )


            print(
                "🗑️ Deleting report:",
                report_key
            )


            try:

                s3.delete_object(
                    Bucket=BUCKET_NAME,
                    Key=report_key
                )

                print(
                    "✅ Report deleted"
                )

            except Exception as report_error:

                print(
                    "⚠️ Could not delete report:",
                    str(report_error)
                )


            print(
                "✅ Resume deleted successfully"
            )


            return response(
                200,
                {
                    "message":
                    "Resume deleted successfully",

                    "key":
                    key
                }
            )


        except Exception as e:

            print(
                "❌ ERROR deleting resume:",
                str(e)
            )

            traceback.print_exc()


            return response(
                500,
                {
                    "error":
                    str(e)
                }
            )

    # ==================================================
    # UNSUPPORTED METHOD
    # ==================================================

    return response(
        405,
        {
            "error":
            f"Method {http_method} not allowed"
        }
    )